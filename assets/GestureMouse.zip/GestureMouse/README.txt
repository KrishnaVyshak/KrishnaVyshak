A Simple virtual mouse made by Krishnavyshak
